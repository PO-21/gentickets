#!/bin/bash



#echo "$0";
#echo "$1";
#echo "${2}";
#echo "$#";



for n in $@
do
  cp -r data/Objects/"Object $n" tmp 
  echo "Object $n"

done






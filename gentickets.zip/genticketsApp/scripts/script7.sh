#!/bin/bash

for n in $@
do
  rm -r data/Objects/"Object $n"
  rm data/Objects/ObjectReplacements/"Object $n" 
  echo "Object $n"

done
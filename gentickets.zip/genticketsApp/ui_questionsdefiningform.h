/********************************************************************************
** Form generated from reading UI file 'questionsdefiningform.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QUESTIONSDEFININGFORM_H
#define UI_QUESTIONSDEFININGFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_questionsDefiningForm
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QTableView *tableView;
    QComboBox *comboBox;
    QLabel *label;
    QLineEdit *lineEdit;

    void setupUi(QWidget *questionsDefiningForm)
    {
        if (questionsDefiningForm->objectName().isEmpty())
            questionsDefiningForm->setObjectName(QStringLiteral("questionsDefiningForm"));
        questionsDefiningForm->resize(469, 419);
        pushButton = new QPushButton(questionsDefiningForm);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(30, 370, 141, 27));
        pushButton_2 = new QPushButton(questionsDefiningForm);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(190, 370, 141, 27));
        tableView = new QTableView(questionsDefiningForm);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(30, 100, 341, 192));
        comboBox = new QComboBox(questionsDefiningForm);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(30, 60, 171, 27));
        label = new QLabel(questionsDefiningForm);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 10, 341, 41));
        lineEdit = new QLineEdit(questionsDefiningForm);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(40, 320, 113, 27));

        retranslateUi(questionsDefiningForm);

        QMetaObject::connectSlotsByName(questionsDefiningForm);
    } // setupUi

    void retranslateUi(QWidget *questionsDefiningForm)
    {
        questionsDefiningForm->setWindowTitle(QApplication::translate("questionsDefiningForm", "Form", 0));
        pushButton->setText(QApplication::translate("questionsDefiningForm", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\262\320\276\320\277\321\200\320\276\321\201", 0));
        pushButton_2->setText(QApplication::translate("questionsDefiningForm", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214 \321\201\320\277\320\270\321\201\320\276\320\272", 0));
        label->setText(QApplication::translate("questionsDefiningForm", "\320\222\321\213\320\261\320\265\321\200\320\270\321\202\320\265 \320\261\320\270\320\273\320\265\321\202\321\213 \321\207\321\202\320\276\320\261\321\213 \320\276\320\277\321\200\320\265\320\264\320\265\320\273\320\270\321\202\321\214 \321\201\320\277\320\270\321\201\320\272\320\270\n"
"\320\264\320\273\321\217 \320\272\320\260\320\266\320\264\320\276\320\263\320\276 \320\262\320\276\320\277\321\200\320\276\321\201\320\260", 0));
    } // retranslateUi

};

namespace Ui {
    class questionsDefiningForm: public Ui_questionsDefiningForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QUESTIONSDEFININGFORM_H

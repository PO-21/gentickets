#include "qlineeditdelegate.h"
#include <QLineEdit>
#include <QTimeEdit>
#include <QDateEdit>
#include <QComboBox>
#include <QPainter>
#include <QDate>
#include <QMessageBox>
#include <QTextEdit>
QLineEditDelegate::QLineEditDelegate(QObject *parent) :
    QItemDelegate(parent)
{
}

QLineEditDelegate::~QLineEditDelegate()
{
}

QWidget *QLineEditDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    (void) option;
    (void) index;

    if (index.column() == 1) {
        QLineEdit *line = new QLineEdit(parent);
        QRegExp exp("[a-zA-Zа-яА-я ]{1,15}");
        line->setValidator(new QRegExpValidator(exp, parent));
        return line;
    }
    if (index.column() == 5) {
        QLineEdit *date = new QLineEdit(parent);
        QRegExp exp("[0-9]{4,4}");
        date->setValidator(new QRegExpValidator(exp, parent));
        return date;
    }
    if (index.column() == 4) {
        QComboBox *editor = new QComboBox(parent);
        editor->setEditable(true);
        editor->clear();
        QStringList s_list;
        s_list.append("осенний");
        s_list.append("весенний");
        editor->addItems(s_list);
        return editor;
    }
}


void QLineEditDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    drawBackground(painter, option, index);
    QItemDelegate::paint(painter, option, index);
}

void QLineEditDelegate::drawBackground(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
}


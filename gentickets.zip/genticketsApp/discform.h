#ifndef DISCFORM_H
#define DISCFORM_H

#include <QWidget>
#include <abstractform.h>
#include <QtSql>
#include <QCloseEvent>

class mainForm;

namespace Ui {
class discForm;
}

class discForm : public QWidget, public AbstractForm
{
    Q_OBJECT

public:
    explicit discForm(QWidget *parent = 0);
    ~discForm();

    void                                setTableHeaders();
    void                                closeEvent(QCloseEvent *ev);
private slots:
    void                                insertButtonReact();
    void                                removeButtonReact();

private:
    Ui::discForm *ui;
};

#endif // DISCFORM_H

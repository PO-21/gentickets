#include "ticketslistform.h"
#include "ui_ticketslistform.h"
#include "mainform.h"

ticketsListForm::ticketsListForm(QWidget *parent) :
    QWidget(parent),
    AbstractForm(),
    ui(new Ui::ticketsListForm)
{

    ui->setupUi(this);
    table        = ui->tableView;
    insertButton = ui->pushButton;
    removeButton = ui->pushButton_2;
    ui->lineEdit->setVisible(false);

    QObject::connect(insertButton, SIGNAL(clicked()), this, SLOT(insertButtonReact()));
    QObject::connect(removeButton, SIGNAL(clicked()), this, SLOT(removeButtonReact()));

    QAbstractItemDelegate *qDeleg = new ticketsListDelegate;

    table->setItemDelegateForColumn(1, qDeleg);
    table->setItemDelegateForColumn(4, qDeleg);
    table->setItemDelegateForColumn(5, qDeleg);
    table->setItemDelegateForColumn(2, new QSqlRelationalDelegate(table));
    table->setItemDelegateForColumn(3, new QSqlRelationalDelegate(table));
}

ticketsListForm::~ticketsListForm()
{
    delete ui;
}

void ticketsListForm::setTableHeaders()
{
    model->setHeaderData(1, Qt::Horizontal, "Наименование списка");
    model->setHeaderData(2, Qt::Horizontal, "Название кафедры");
    model->setHeaderData(3, Qt::Horizontal, "Дисциплина");
    model->setHeaderData(4, Qt::Horizontal, "уч. год");
    model->setHeaderData(5, Qt::Horizontal, "Семестр");
    model->setHeaderData(6, Qt::Horizontal, "Число билетов");
    model->setHeaderData(7, Qt::Horizontal, "Вопросов в билете");

    model->setRelation(2, QSqlRelation("Dep","depID","depName"));
    model->setRelation(3, QSqlRelation("Disc","discID","discName"));
    model->select();

    table->resizeColumnsToContents();
    table->hideColumn(0);
}



void ticketsListForm::insertButtonReact()
{
    QSqlRecord record;
    record = model->record();

    QSqlQuery q1("select depID from Dep");
    QSqlQuery q2("select discID from Disc");
    q1.first();
    q2.first();
    if (q1.isValid() == false || q2.isValid() == false) {
        QMessageBox::warning(this, "Ошибка", "Заполните справочники!");
        return;
    }
    int depID = q1.value(0).toInt();
    int discID = q2.value(0).toInt();
    record.setValue("depName", depID);
    record.setValue("discName", discID);

    model->insertRecord(-1, record);
    model->select();
    wasChanged = true;
}

void ticketsListForm::removeButtonReact()
{
        if (!model->removeRow(table->currentIndex().row()))
             QMessageBox::warning(this, "Ошибка", model->lastError().databaseText());
        else
            wasChanged = true;
        model->select();

}


void ticketsListForm::closeEvent(QCloseEvent *ev)
{
    if (!mainF->isEnabled())
        mainF->setEnabled(true);
    if (wasChanged)
    mainF->fillTicketsGeneratingCmBox();

}


QWidget *ticketsListDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    (void) option;
    (void) index;

    if (index.column() == 1) {
        QLineEdit *line = new QLineEdit(parent);
        QRegExp exp("[0-9a-zA-Zа-яА-я ]{1,25}");
        line->setValidator(new QRegExpValidator(exp, parent));
        return line;
    }
    if (index.column() == 4) {
        QLineEdit *date = new QLineEdit(parent);
        QRegExp exp("[0-9]{4,4}");
        date->setValidator(new QRegExpValidator(exp, parent));
        return date;
    }
    if (index.column() == 5) {
        QComboBox *editor = new QComboBox(parent);
        editor->setEditable(true);
        editor->clear();
        QStringList s_list;
        s_list.append("осенний");
        s_list.append("весенний");
        editor->addItems(s_list);
        return editor;
    }
    if (index.column() == 7)
        return NULL;


}

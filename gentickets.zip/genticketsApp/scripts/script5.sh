#!/bin/bash


cp -r data/inputFiles/Object\ * data/Objects;

rm -r data/inputFiles/*



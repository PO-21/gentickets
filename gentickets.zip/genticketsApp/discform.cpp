#include "discform.h"
#include "ui_discform.h"
#include "mainform.h"
discForm::discForm(QWidget *parent) :
    QWidget(parent),
    AbstractForm(),
    ui(new Ui::discForm)
{
    ui->setupUi(this);
    table        = ui->tableView;
    insertButton = ui->pushButton;
    removeButton = ui->pushButton_2;
    ui->lineEdit->setVisible(false);
    QObject::connect(insertButton, SIGNAL(clicked()), this, SLOT(insertButtonReact()));
    QObject::connect(removeButton, SIGNAL(clicked()), this, SLOT(removeButtonReact()));

}

discForm::~discForm()
{
    delete ui;
}


void discForm::setTableHeaders()
{
    model->setHeaderData(1, Qt::Horizontal, "Название дисциплины");
    table->resizeColumnsToContents();
    table->hideColumn(0);
}



void discForm::insertButtonReact()
{
    QSqlRecord record;
    record = model->record();
    model->insertRecord(-1, record);
    model->select();
}

void discForm::removeButtonReact()
{
    if (!model->removeRow(table->currentIndex().row()))
        QMessageBox::warning(this, "Ошибка", model->lastError().databaseText());
    model->select();
}


void discForm::closeEvent(QCloseEvent *ev)
{
    if (!mainF->isEnabled())
        mainF->setEnabled(true);
}

#ifndef QUESTIONSLOADINGFORM_H
#define QUESTIONSLOADINGFORM_H

#include <QWidget>
#include <abstractform.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

class mainForm;

namespace Ui {
class questionsLoadingForm;
}

class questionsLoadingForm : public QWidget, public AbstractForm
{
    Q_OBJECT

public:
    explicit questionsLoadingForm(QWidget *parent = 0);
    ~questionsLoadingForm();
    void                                setTableHeaders();
    void                                closeEvent(QCloseEvent*ev);
    void                                fillQuestListCmBox();

    QComboBox*                          questListCmBox;
    int                                 questListId;
    QString                             objects;

private slots:
    void                                insertButtonReact();
    void                                removeButtonReact();


    void on_comboBox_currentTextChanged(const QString &arg1);



private:
    Ui::questionsLoadingForm *ui;
};

#endif // QUESTIONSLOADINGFORM_H

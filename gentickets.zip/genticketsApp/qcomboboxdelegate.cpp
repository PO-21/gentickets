#include "qcomboboxdelegate.h"
#include <QComboBox>

#include <QLineEdit>
#include <QTimeEdit>
#include <QDateEdit>
#include <QPainter>

QComboBoxDelegate::QComboBoxDelegate(QObject *parent) :
    QItemDelegate(parent)
{

}

void QComboBoxDelegate::determinetable(int n, QString tableName, QSqlDatabase dbName)
{
    DB = dbName;
    name = tableName;
    indexc = n;
}


QWidget *QComboBoxDelegate::createEditor(QWidget * parent, const QStyleOptionViewItem & option,const QModelIndex & index) const
{
    (void) option;
    (void) index;
    if (index.column() == 1 || index.column() == 0){
        QMessageBox::warning(parent, "Ошибка", "Нельзя изменять это поле!");
        return NULL;
    }

    if (index.column() == 2 || index.column() == 3) {

        QComboBox *editor = new QComboBox(parent);
        editor->setEditable(true);
        QSqlTableModel * model = new QSqlTableModel(0, DB);
        model->setTable(name);
        model->select();
        editor->setModel(model);
        editor->setModelColumn(indexc);

        return editor;
    }
}

void QComboBoxDelegate::setEditorData(QWidget * editor, const QModelIndex & index) const
{
    QString value = index.model()->data(index, Qt::DisplayRole).toString();
    QComboBox *combo = static_cast<QComboBox*>(editor);
    combo->setEditText(value);
}

void	QComboBoxDelegate::setModelData(QWidget * editor, QAbstractItemModel * model,
                                           const QModelIndex & index) const
{
    QComboBox * combo = static_cast<QComboBox*>(editor);
    model->setData(index,combo->currentText());
}

void	QComboBoxDelegate::updateEditorGeometry(QWidget * editor, const QStyleOptionViewItem & option,
                          const QModelIndex & index) const
{
    editor->setGeometry(option.rect);
    (void) index;
}

void QComboBoxDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
      drawBackground(painter, option, index);
      QItemDelegate::paint(painter, option, index);
}


void QComboBoxDelegate::drawBackground(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
}


#!/bin/bash

cd data/inputFiles;
 

unzip in.zip -d /home/user/genticketsApp/data/inputFiles;
#rm in.zip;

 





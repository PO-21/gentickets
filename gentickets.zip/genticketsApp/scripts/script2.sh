#!/bin/bash

cd data/outputFiles/output/
zip -r output.zip *
mv output.zip output.odt
cp output.odt /home/user


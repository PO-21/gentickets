#include "questionsdefiningform.h"
#include "ui_questionsdefiningform.h"
#include "mainform.h"
questionsDefiningForm::questionsDefiningForm(QWidget *parent) :
    QWidget(parent),
    AbstractForm(),
    ui(new Ui::questionsDefiningForm)
{
    ui->setupUi(this);
    table        = ui->tableView;
    insertButton = ui->pushButton;
    removeButton = ui->pushButton_2;
    ui->lineEdit->setVisible(false);
    ticketsListCmBox = ui->comboBox;

    QObject::connect(insertButton, SIGNAL(clicked()), this, SLOT(insertButtonReact()));
    QObject::connect(removeButton, SIGNAL(clicked()), this, SLOT(removeButtonReact()));


    table->setItemDelegateForColumn(2, new QSqlRelationalDelegate(table));
    QComboBoxDelegate* questListDeleg = new QComboBoxDelegate;
    table->setItemDelegateForColumn(1, questListDeleg);
}

questionsDefiningForm::~questionsDefiningForm()
{
    delete ui;
}

void questionsDefiningForm::insertButtonReact()
{


    QSqlQuery query_1;
    query_1.prepare("select count(*) from QuestOfTickets where ticketsListID = ?");
    query_1.addBindValue(ticketsListID);
    query_1.exec();
    query_1.first();
    int recNum = query_1.value(0).toInt(); // текущее число записей в таблице

    QSqlQuery query_2;
    query_2.prepare("select questNumInTicket from TicketsList where ticketsListID = ?");
    query_2.addBindValue(ticketsListID);
    query_2.exec();
    query_2.first();
    int questNumInTicket = query_2.value(0).toInt(); // Число вопросов в билете



    if ((recNum + 1) > questNumInTicket) {
        QMessageBox::warning(this, "Ошибка", "Списки для всех вопросов определены\nБольше вопросов в билете нет!");
        return;
    } else {

    QSqlRecord record;
    record = model->record();

    QSqlQuery query;
    query.exec("select questListID from QuestionList");
    query.first();

    if (query.isValid() == false) {
        QMessageBox::warning(this, "Ошибка", "Заполните таблицу \"списки вопросов\"!");
        return;
    }

    record.setValue("ticketsListID", ticketsListID);
    record.setValue("questNumInTicket", recNum + 1);
    record.setValue("questListName", query.value(0).toString());


    model->insertRecord(-1, record);
    model->select();
    }
}

void questionsDefiningForm::removeButtonReact()
{
    QSqlQuery deleteQuery;
    deleteQuery.prepare("delete from QuestOfTickets where ticketsListID = ?");
    deleteQuery.addBindValue(ticketsListID);
    if (!deleteQuery.exec())
        QMessageBox::warning(this, "Ошибка", model->lastError().databaseText());


    model->select();

}

void questionsDefiningForm::setTableHeaders()
{

    model->setHeaderData(1, Qt::Horizontal, "Номер вопроса");
    model->setHeaderData(2, Qt::Horizontal, "Список вопросов");

    model->setRelation(2, QSqlRelation("QuestionList","questListID","questListName"));
    model->select();

    table->resizeColumnsToContents();
    table->hideColumn(0);
}

void questionsDefiningForm::closeEvent(QCloseEvent *ev)
{
    if (!mainF->isEnabled())
        mainF->setEnabled(true);
}

void questionsDefiningForm::fillTicketsListCmBox()
{
    ticketsListCmBox->clear();
    QSqlQuery query("select ticketsListName from TicketsList");
    QStringList s_list;
        while(query.next()) {
            s_list.append(query.value(0).toString());
        }
        ticketsListCmBox->addItems(s_list);
}

void questionsDefiningForm::on_comboBox_currentTextChanged(const QString &arg1)
{
    QSqlQuery query;
    query.prepare("select ticketsListID from TicketsList where ticketsListName = ?");
    query.addBindValue(arg1);
    query.exec();

    query.first();
    ticketsListID = query.value(0).toInt();
    QString arg = query.value(0).toString();
    model->setFilter("ticketsListID = '" + arg + "'");
    model->select();

}

#ifndef QCOMBOBOXDELEGATE_H
#define QCOMBOBOXDELEGATE_H


#include <QItemDelegate>
#include <QtSql>
#include <QMessageBox>

class QComboBoxDelegate : public QItemDelegate
{
    Q_OBJECT

public:
   explicit QComboBoxDelegate(QObject *parent = 0);

   void determinetable(int n, QString tableName ,QSqlDatabase dbName);

   virtual QWidget *createEditor(QWidget * parent,const QStyleOptionViewItem & option,
                             const QModelIndex & index) const;

   virtual void	setEditorData(QWidget * editor, const QModelIndex & index) const;

   virtual void	setModelData(QWidget * editor, QAbstractItemModel * model, const QModelIndex & index) const;

   virtual void	updateEditorGeometry(QWidget * editor, const QStyleOptionViewItem & option,
                             const QModelIndex & index) const;

   virtual void	paint(QPainter * painter, const QStyleOptionViewItem & option, const QModelIndex & index) const;

private:
    int indexc;
    QString name,st;
    QSqlDatabase DB;

protected:
    void	drawBackground(QPainter * painter, const QStyleOptionViewItem & option, const QModelIndex & index) const;

};

#endif // QCOMBOBOXDELEGATE_H

#ifndef GENTICKETS_H
#define GENTICKETS_H

#include "gentickets_global.h"
#include <QtSql>
#include <QtXml>
#include <QtXmlPatterns/QXmlQuery>
#include <QVariantList>

class GENTICKETSSHARED_EXPORT gentickets
{

    public:

        void                    setConnection(QSqlDatabase openedDB);
        int                     loadQuestionsList(int questListID, QString filename);    // заполняем таблицу вопросы
        int                     generateTickets(QString ticketsListID);                     //ID списка билетов; заполняем таблицу билеты
        void                    createOutputFile(QString ticketsListID, QString filename);
        QVector<QDomElement>    tickets(QDomDocument& domDoc, QString ticketsIdForGenerating);
        QDomElement             makeElement(QDomDocument& domDoc, const QString& strName,
                                            const QString& strAttr = QString::null,
                                            const QString& strText = QString::null
                                            );

    private:
        QSqlDatabase            db;
        QSqlTableModel          model;
        QFile                   file;




};

#endif // GENTICKETS_H

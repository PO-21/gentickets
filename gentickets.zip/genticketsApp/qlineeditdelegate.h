#ifndef QLINEEDITDELEGATE_H
#define QLINEEDITDELEGATE_H

#include <QItemDelegate>
#include <QVector>
#include <QtSql>
#include <QDate>

class QLineEditDelegate : public QItemDelegate
{
    Q_OBJECT
public:
    explicit QLineEditDelegate(QObject *parent = 0);
    ~QLineEditDelegate();

    virtual QWidget *createEditor(QWidget * parent,const QStyleOptionViewItem & option,
                              const QModelIndex & index) const;

    virtual void	paint(QPainter * painter, const QStyleOptionViewItem & option, const QModelIndex & index) const;

protected:
    void	drawBackground(QPainter * painter, const QStyleOptionViewItem & option, const QModelIndex & index) const;
private:

};

#endif // QLINEEDITDELEGATE_H

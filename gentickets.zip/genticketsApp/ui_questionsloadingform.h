/********************************************************************************
** Form generated from reading UI file 'questionsloadingform.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QUESTIONSLOADINGFORM_H
#define UI_QUESTIONSLOADINGFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_questionsLoadingForm
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QTableView *tableView;
    QComboBox *comboBox;
    QLabel *label;
    QLineEdit *lineEdit;

    void setupUi(QWidget *questionsLoadingForm)
    {
        if (questionsLoadingForm->objectName().isEmpty())
            questionsLoadingForm->setObjectName(QStringLiteral("questionsLoadingForm"));
        questionsLoadingForm->resize(561, 468);
        pushButton = new QPushButton(questionsLoadingForm);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(18, 400, 151, 27));
        pushButton_2 = new QPushButton(questionsLoadingForm);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(180, 400, 131, 27));
        tableView = new QTableView(questionsLoadingForm);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(10, 70, 521, 261));
        comboBox = new QComboBox(questionsLoadingForm);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(10, 30, 171, 27));
        label = new QLabel(questionsLoadingForm);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 10, 231, 17));
        lineEdit = new QLineEdit(questionsLoadingForm);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(20, 350, 113, 27));

        retranslateUi(questionsLoadingForm);

        QMetaObject::connectSlotsByName(questionsLoadingForm);
    } // setupUi

    void retranslateUi(QWidget *questionsLoadingForm)
    {
        questionsLoadingForm->setWindowTitle(QApplication::translate("questionsLoadingForm", "Form", 0));
        pushButton->setText(QApplication::translate("questionsLoadingForm", "\320\227\320\260\320\263\321\200\321\203\320\267\320\270\321\202\321\214 \320\262\320\276\320\277\321\200\320\276\321\201\321\213", 0));
        pushButton_2->setText(QApplication::translate("questionsLoadingForm", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214 \321\201\320\277\320\270\321\201\320\276\320\272", 0));
        label->setText(QApplication::translate("questionsLoadingForm", "\320\222\321\213\320\261\320\265\321\200\320\270\321\202\320\265 \321\201\320\277\320\270\321\201\320\276\320\272 \320\262\320\276\320\277\321\200\320\276\321\201\320\276\320\262", 0));
    } // retranslateUi

};

namespace Ui {
    class questionsLoadingForm: public Ui_questionsLoadingForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QUESTIONSLOADINGFORM_H

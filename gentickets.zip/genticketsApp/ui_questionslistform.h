/********************************************************************************
** Form generated from reading UI file 'questionslistform.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QUESTIONSLISTFORM_H
#define UI_QUESTIONSLISTFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_questionsListForm
{
public:
    QTableView *tableView;
    QLabel *label;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit;

    void setupUi(QWidget *questionsListForm)
    {
        if (questionsListForm->objectName().isEmpty())
            questionsListForm->setObjectName(QStringLiteral("questionsListForm"));
        questionsListForm->resize(662, 410);
        tableView = new QTableView(questionsListForm);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(10, 50, 641, 192));
        label = new QLabel(questionsListForm);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 20, 211, 17));
        pushButton = new QPushButton(questionsListForm);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(30, 360, 99, 27));
        pushButton_2 = new QPushButton(questionsListForm);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(170, 360, 99, 27));
        lineEdit = new QLineEdit(questionsListForm);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(40, 290, 113, 27));

        retranslateUi(questionsListForm);

        QMetaObject::connectSlotsByName(questionsListForm);
    } // setupUi

    void retranslateUi(QWidget *questionsListForm)
    {
        questionsListForm->setWindowTitle(QApplication::translate("questionsListForm", "\320\241\320\277\320\270\321\201\320\272\320\270 \320\262\320\276\320\277\321\200\320\276\321\201\320\276\320\262", 0));
        label->setText(QApplication::translate("questionsListForm", "\320\241\320\277\320\270\321\201\320\272\320\270 \320\262\320\276\320\277\321\200\320\276\321\201\320\276\320\262", 0));
        pushButton->setText(QApplication::translate("questionsListForm", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214", 0));
        pushButton_2->setText(QApplication::translate("questionsListForm", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214", 0));
    } // retranslateUi

};

namespace Ui {
    class questionsListForm: public Ui_questionsListForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QUESTIONSLISTFORM_H

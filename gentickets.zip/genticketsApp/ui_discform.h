/********************************************************************************
** Form generated from reading UI file 'discform.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DISCFORM_H
#define UI_DISCFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_discForm
{
public:
    QTableView *tableView;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;
    QLineEdit *lineEdit;

    void setupUi(QWidget *discForm)
    {
        if (discForm->objectName().isEmpty())
            discForm->setObjectName(QStringLiteral("discForm"));
        discForm->resize(286, 377);
        tableView = new QTableView(discForm);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(10, 40, 251, 201));
        pushButton = new QPushButton(discForm);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 330, 121, 27));
        pushButton_2 = new QPushButton(discForm);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(140, 330, 121, 27));
        label = new QLabel(discForm);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(10, 20, 141, 17));
        lineEdit = new QLineEdit(discForm);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(10, 270, 113, 27));

        retranslateUi(discForm);

        QMetaObject::connectSlotsByName(discForm);
    } // setupUi

    void retranslateUi(QWidget *discForm)
    {
        discForm->setWindowTitle(QApplication::translate("discForm", "\320\224\320\270\321\201\321\206\320\270\320\277\320\273\320\270\320\275\320\260", 0));
        pushButton->setText(QApplication::translate("discForm", "\320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214", 0));
        pushButton_2->setText(QApplication::translate("discForm", "\321\203\320\264\320\260\320\273\320\270\321\202\321\214", 0));
        label->setText(QApplication::translate("discForm", "\320\224\320\270\321\201\321\206\320\270\320\277\320\273\320\270\320\275\320\260", 0));
    } // retranslateUi

};

namespace Ui {
    class discForm: public Ui_discForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DISCFORM_H

#ifndef ABSTRACTFORM_H
#define ABSTRACTFORM_H

#include <QtSql>
#include <QWidget>
#include <QTableView>
#include <QPushButton>
#include <QCloseEvent>

class mainForm;

class AbstractForm
{
    public:
                                            AbstractForm();
                                            ~AbstractForm();
        void                                setTable(const QString tableName);
        void                                setTableHeaders();
        void                                setMainForm(mainForm* main);
        void                                closeEvent(QCloseEvent*ev);
    public slots:
        void                                insertButtonReact();
        void                                removeButtonReact();

    protected:
        QSqlDatabase                        db;
        QTableView*                         table;
        QSqlRelationalTableModel*           model;
        QPushButton*                        insertButton;
        QPushButton*                        removeButton;
        QString                             tableName;
        mainForm*                           mainF;
        bool                                wasChanged;

    public:
        virtual void                        setConnection(QSqlDatabase openedDB);
};

#endif // ABSTRACTFORM_H

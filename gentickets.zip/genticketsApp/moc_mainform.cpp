/****************************************************************************
** Meta object code from reading C++ file 'mainform.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_mainForm_t {
    QByteArrayData data[16];
    char stringdata0[279];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_mainForm_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_mainForm_t qt_meta_stringdata_mainForm = {
    {
QT_MOC_LITERAL(0, 0, 8), // "mainForm"
QT_MOC_LITERAL(1, 9, 17), // "connectToDatabase"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 11), // "openDepForm"
QT_MOC_LITERAL(4, 40, 12), // "openDiscForm"
QT_MOC_LITERAL(5, 53, 21), // "openQuestionsListForm"
QT_MOC_LITERAL(6, 75, 19), // "openTicketsListForm"
QT_MOC_LITERAL(7, 95, 24), // "openQuestionsLoadingForm"
QT_MOC_LITERAL(8, 120, 25), // "openQuestionsDefiningFrom"
QT_MOC_LITERAL(9, 146, 32), // "on_comboBox_3_currentTextChanged"
QT_MOC_LITERAL(10, 179, 4), // "arg1"
QT_MOC_LITERAL(11, 184, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(12, 208, 19), // "setAllWidgetsEnable"
QT_MOC_LITERAL(13, 228, 4), // "flag"
QT_MOC_LITERAL(14, 233, 23), // "on_pushButton_5_clicked"
QT_MOC_LITERAL(15, 257, 21) // "on_pushButton_clicked"

    },
    "mainForm\0connectToDatabase\0\0openDepForm\0"
    "openDiscForm\0openQuestionsListForm\0"
    "openTicketsListForm\0openQuestionsLoadingForm\0"
    "openQuestionsDefiningFrom\0"
    "on_comboBox_3_currentTextChanged\0arg1\0"
    "on_pushButton_2_clicked\0setAllWidgetsEnable\0"
    "flag\0on_pushButton_5_clicked\0"
    "on_pushButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_mainForm[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   74,    2, 0x08 /* Private */,
       3,    0,   75,    2, 0x08 /* Private */,
       4,    0,   76,    2, 0x08 /* Private */,
       5,    0,   77,    2, 0x08 /* Private */,
       6,    0,   78,    2, 0x08 /* Private */,
       7,    0,   79,    2, 0x08 /* Private */,
       8,    0,   80,    2, 0x08 /* Private */,
       9,    1,   81,    2, 0x08 /* Private */,
      11,    0,   84,    2, 0x08 /* Private */,
      12,    1,   85,    2, 0x08 /* Private */,
      14,    0,   88,    2, 0x08 /* Private */,
      15,    0,   89,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void mainForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        mainForm *_t = static_cast<mainForm *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->connectToDatabase(); break;
        case 1: _t->openDepForm(); break;
        case 2: _t->openDiscForm(); break;
        case 3: _t->openQuestionsListForm(); break;
        case 4: _t->openTicketsListForm(); break;
        case 5: _t->openQuestionsLoadingForm(); break;
        case 6: _t->openQuestionsDefiningFrom(); break;
        case 7: _t->on_comboBox_3_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 8: _t->on_pushButton_2_clicked(); break;
        case 9: _t->setAllWidgetsEnable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->on_pushButton_5_clicked(); break;
        case 11: _t->on_pushButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject mainForm::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_mainForm.data,
      qt_meta_data_mainForm,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *mainForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *mainForm::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_mainForm.stringdata0))
        return static_cast<void*>(const_cast< mainForm*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int mainForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 12;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

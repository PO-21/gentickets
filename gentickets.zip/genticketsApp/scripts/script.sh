#!/bin/bash

cd data/outputFiles;
libreoffice --invisible --convert-to odt output.doc;
mv output.odt output.zip;
unzip output.zip -d /home/ivan/genticketsApp/data/outputFiles/output;


cd ..
 
mkdir data/outputFiles/output/ObjectReplacements

for n in $@
do
  cp -r data/Objects/"Object $n" data/outputFiles/output
  
  cp data/Objects/ObjectReplacements/"Object $n" data/outputFiles/output/ObjectReplacements 
  echo "Object $n"

done 
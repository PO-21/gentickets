#include "abstractform.h"
#include "mainform.h"
AbstractForm::AbstractForm() : wasChanged(false)
{
}

AbstractForm::~AbstractForm()
{
}

void AbstractForm::setTable(const QString tabName)
{
    model = new QSqlRelationalTableModel(0, db);
    model->setTable(tabName);
    model->select();
    table->setModel(model);
    table->show();
    model->setEditStrategy(QSqlRelationalTableModel::OnFieldChange);
    tableName = tabName;
}

void AbstractForm::setTableHeaders()
{
}

void AbstractForm::setMainForm(mainForm *main)
{
    mainF = main;
}

void AbstractForm::closeEvent(QCloseEvent *ev)
{
}

void AbstractForm::setConnection(QSqlDatabase openedDB)
{
    db = openedDB;
}


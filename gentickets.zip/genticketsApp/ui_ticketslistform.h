/********************************************************************************
** Form generated from reading UI file 'ticketslistform.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TICKETSLISTFORM_H
#define UI_TICKETSLISTFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ticketsListForm
{
public:
    QTableView *tableView;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label_2;
    QLineEdit *lineEdit;

    void setupUi(QWidget *ticketsListForm)
    {
        if (ticketsListForm->objectName().isEmpty())
            ticketsListForm->setObjectName(QStringLiteral("ticketsListForm"));
        ticketsListForm->resize(982, 506);
        tableView = new QTableView(ticketsListForm);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(10, 30, 931, 311));
        pushButton = new QPushButton(ticketsListForm);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(20, 440, 99, 27));
        pushButton_2 = new QPushButton(ticketsListForm);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(180, 440, 99, 27));
        label_2 = new QLabel(ticketsListForm);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 10, 201, 17));
        lineEdit = new QLineEdit(ticketsListForm);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(40, 380, 113, 27));

        retranslateUi(ticketsListForm);

        QMetaObject::connectSlotsByName(ticketsListForm);
    } // setupUi

    void retranslateUi(QWidget *ticketsListForm)
    {
        ticketsListForm->setWindowTitle(QApplication::translate("ticketsListForm", "\320\241\320\277\320\270\321\201\320\272\320\270 \320\261\320\270\320\273\320\265\321\202\320\276\320\262", 0));
        pushButton->setText(QApplication::translate("ticketsListForm", "\320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214", 0));
        pushButton_2->setText(QApplication::translate("ticketsListForm", "\321\203\320\264\320\260\320\273\320\270\321\202\321\214", 0));
        label_2->setText(QApplication::translate("ticketsListForm", "\321\201\320\277\320\270\321\201\320\272\320\270 \320\261\320\270\320\273\320\265\321\202\320\276\320\262", 0));
    } // retranslateUi

};

namespace Ui {
    class ticketsListForm: public Ui_ticketsListForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TICKETSLISTFORM_H

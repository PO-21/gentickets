#include "questionsloadingform.h"
#include "ui_questionsloadingform.h"
#include "mainform.h"

questionsLoadingForm::questionsLoadingForm(QWidget *parent) :
    QWidget(parent),
    AbstractForm(),
    objects(""),
    ui(new Ui::questionsLoadingForm)
{
    ui->setupUi(this);
    table        = ui->tableView;
    insertButton = ui->pushButton;
    removeButton = ui->pushButton_2;
    questListCmBox = ui->comboBox;
    ui->lineEdit->setVisible(false);

    insertButton->setEnabled(true);
    removeButton->setEnabled(true);

    QObject::connect(insertButton, SIGNAL(clicked()), this, SLOT(insertButtonReact()));
    QObject::connect(removeButton, SIGNAL(clicked()), this, SLOT(removeButtonReact()));

}

questionsLoadingForm::~questionsLoadingForm()
{
    delete ui;
}

void questionsLoadingForm::insertButtonReact()
{
    QSqlQuery query1;
    query1.exec("select questListID from QuestionList");
    query1.first();

    if (query1.isValid() == false) {
        QMessageBox::warning(this, "Ошибка", "Заполните таблицу \"списки вопросов\"!");
        return;
    }

    QSqlQuery helpQuery;
    helpQuery.prepare("select count(*) from Questions where questListID = ?");
    helpQuery.addBindValue(questListId);
    helpQuery.exec();
    helpQuery.first();
    if (helpQuery.value(0).toInt() != 0) {
        QMessageBox::warning(this, "Ошибка", "Список заполнен: очистите, чтобы добавить новые вопросы!");
        return;
    }


   QString filename = QFileDialog::getOpenFileName(0, tr("Открыть файл"));
    if (filename.length() == 0)
       return;

    char* fileName = filename.toUtf8().data();


   int pd = fork();
        int stat;
        if (!pd)
            execlp("cp", "cp",  "-r", fileName, "data/inputFiles/in.zip", NULL);
        else
            waitpid(pd, &stat, 0);


    QProcess *proc = new QProcess(this);
    QStringList arguments;
    arguments << "-c" << "scripts/script0.sh";
    proc->startDetached("sh",arguments);
    QTest::qSleep(1000);

    QDir dir1, dir2;
    dir1.cd("data/inputFiles");
    dir2.cd("data/Objects");

    QStringList filters;
    filters << "Object\ *";
    dir1.setNameFilters(filters);
    dir2.setNameFilters(filters);

    int numSrcObjects;          // Количество файлов Object во входном документе
    int numTmpObjects;          // Количество файлов Object во временной папке Objects
    numSrcObjects = dir1.entryList().count();
    numTmpObjects = dir2.entryList().count();

    QStringList objectsList = dir2.entryList();

    QByteArray fileData;
    QFile file("data/inputFiles/content.xml");
    if(!file.open(QIODevice::ReadWrite)) // open for read and write
       return;
    fileData = file.readAll();
    QString text(fileData);
    text.remove( QRegExp( "<(?:text:span)[^>]*>", Qt::CaseInsensitive ) );
    text.remove( QRegExp( "<(?:/text:span)[^>]*>", Qt::CaseInsensitive ) );

   file.remove();

   // Нахождение максимального номера файла в папке Objects-----------------

   if (numSrcObjects != 0) {
    if (numTmpObjects != 0) {
        QString max = objectsList.at(0);
        for (int i = 1; i < objectsList.size(); ++i) {
            if (objectsList.at(i).size() > max.size())
                max = objectsList.at(i);
            if (objectsList.at(i).size() < max.size())
                continue;
            if (objectsList.at(i) > max)
                max = objectsList.at(i);
        }

        QString result;
        for (int i = max.indexOf("A") + 1; i < max.size(); ++i)
            result.append(max[i]);

        int num = result.toInt();
   //--------------------------------------------------------------------


    int i,j;

        for (i = 1, j = num+1; i <= numSrcObjects, j <= numSrcObjects+num; ++i, ++j) {
            QString oldName = QString("%1 %2").arg("Object").arg(i);
            QString newName = QString("%1 %2%3").arg("Object").arg("A").arg(j);
            text.replace(oldName, newName);
            objects.append(newName + " "); // Добавление в таблицу список вопросов всех объектов связанных с этим списком
            dir1.rename(oldName, newName);
            QFile file2;
            file2.copy(dir1.path() + "/ObjectReplacements/" + oldName, dir2.path() + "/ObjectReplacements/" + newName);
        }
    } else {
        for (int i = 1; i <= numSrcObjects; ++i) {
            QString oldName = QString("%1 %2").arg("Object").arg(i);
            QString newName = QString("%1 %2%3").arg("Object").arg("A").arg(i);
            dir1.rename(oldName, newName);
            text.replace(oldName, newName);
            objects.append(newName + " "); // Добавление в таблицу список вопросов всех объектов связанных с этим списком
            QFile file2;
            file2.copy(dir1.path() + "/ObjectReplacements/" + oldName, dir2.path() + "/ObjectReplacements/" + newName);
        }
    }

    // копирование переименованных объектов во временную папку Objects
    QProcess  *proc2 = new QProcess(this);
    QString program2 = "sh";
    QStringList arguments2;
    arguments2 << "-c" << "scripts/script5.sh";
    proc2->startDetached(program2, arguments2);

    //-----------------------------------------


    // добавить QString c именами объектов загружаемых в этот список
    objects.remove(objects.size() - 1, 1);
    //qDebug() << objects;

    QSqlQuery addObjectsQuery;
    addObjectsQuery.prepare("update QuestionList set objectsList = ? where questListID = ?");
    addObjectsQuery.addBindValue(objects);
    addObjectsQuery.addBindValue(questListId);
    addObjectsQuery.exec();
    objects.clear();

}

    QList<int> beg, end;

       int k = 0;
       while ((k = text.indexOf("<text:p", k)) != -1) {
           beg.push_back(k + 29);
           ++k;
       }

       int p = 0;
       while ((p = text.indexOf("</text:p>", p)) != -1) {
           end.push_back(p);
           ++p;
       }

            file.setFileName("data/inputFiles/content.txt");
           if (!file.open(QIODevice::ReadWrite | QIODevice::Text))
               return;

             QTextStream out(&file);

             QList<int>::iterator iter;
             QList<int>::iterator iter2;
             for (iter = beg.begin(), iter2 = end.begin(); iter != beg.end(), iter2 != end.end(); ++iter, ++iter2) {
                 for (int i = *iter; i < *iter2; ++i)
                     out << text[i];
                     out  << "\n\n";

                }

             file.close();


    QSqlQuery query;
    query.prepare("select questListID from QuestionList where questListName = ?");
    query.addBindValue(questListCmBox->currentText());
    query.exec();
    query.first();
    mainF->Tickets.loadQuestionsList(query.value(0).toInt(), dir1.path() + "/content.txt");
    model->select();

    int pd2 = fork();
         int stat2;
         if (!pd2)
             execlp("rm", "rm", "data/inputFiles/content.txt", NULL);
         else
             waitpid(pd2, &stat2, 0);

}

void questionsLoadingForm::removeButtonReact()
{
    QSqlQuery query;
    query.prepare("select questListID from QuestionList where questListName = ?");
    query.addBindValue(questListCmBox->currentText());
    query.exec();
    query.first();


    qDebug() << questListCmBox->currentText();
    QSqlQuery deleteQuery;
    deleteQuery.prepare("delete from Questions where questListID = ?");
    deleteQuery.addBindValue(query.value(0).toString());
    if (!deleteQuery.exec()) {
        QMessageBox::warning(this, "Ошибка", model->lastError().databaseText());
        return;
    }

    QSqlQuery rmFilesQuery;
    rmFilesQuery.prepare("select objectsList from QuestionList where questListID = ?");
    rmFilesQuery.addBindValue(questListId);
    rmFilesQuery.exec();
    rmFilesQuery.first();

    QString Objects = rmFilesQuery.value(0).toString();
    if (Objects == "") {
        QMessageBox::warning(this, "Ошибка", "В списке нет вопросов");
        return;
    }

    QProcess  *proc = new QProcess(this);
    QString program = "sh";
    QStringList arguments;
    QString pathToScript("scripts/script7.sh ");
    qDebug() << Objects;
    Objects.remove("Object");
    pathToScript.append(Objects);
    arguments << "-c" << pathToScript;
    proc->startDetached(program, arguments);


    QSqlQuery delObjectsQuery;
    delObjectsQuery.prepare("update QuestionList set objectsList = ? where questListID = ?");
    delObjectsQuery.addBindValue("");
    delObjectsQuery.addBindValue(questListId);
    delObjectsQuery.exec();

    model->select();

}

void questionsLoadingForm::setTableHeaders()
{
    model->setHeaderData(0, Qt::Horizontal, "Номер вопроса");
    model->setHeaderData(2, Qt::Horizontal, "Тело вопроса");
    model->setHeaderData(3, Qt::Horizontal, "сложность");
    model->setHeaderData(4, Qt::Horizontal, "тема");    
    table->resizeColumnToContents(0);
    table->resizeColumnToContents(3);
    table->resizeColumnToContents(4);
    table->setColumnWidth(2, 230);
    table->hideColumn(1);
    table->show();


}

void questionsLoadingForm::closeEvent(QCloseEvent *ev)
{
    if (!mainF->isEnabled())
        mainF->setEnabled(true);
}

void questionsLoadingForm::fillQuestListCmBox()
{
    questListCmBox->clear();
    QSqlQuery query("select questListName from QuestionList");
    QStringList s_list;
        while(query.next()) {
            s_list.append(query.value(0).toString());
        }
    questListCmBox->addItems(s_list);

}


void questionsLoadingForm::on_comboBox_currentTextChanged(const QString &arg1)
{
    QSqlQuery query;
    query.prepare("select questListID from QuestionList where questListName = ?");
    query.addBindValue(arg1);
    query.exec();
    query.first();

    questListId = query.value(0).toInt();
    QString arg = query.value(0).toString();
    model->setFilter("questListID = '" + arg + "'");
    model->select();
}



#include "gentickets.h"

void gentickets::setConnection(QSqlDatabase openedDB)
{
    db = openedDB;
}

int gentickets::loadQuestionsList(int questListID, QString filename)
{
    QByteArray fileData;
    file.setFileName(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        return 1;
    }

    fileData = file.readAll();
    QString text(fileData);

    QString topic;
    QString body;
    QString complexity;

    int i = 0;
    int questNum = 0;

    while (i < text.length()) {

    QSqlQuery query;
    query.prepare("insert into Questions(questNumInList, questListID, questBody, questLevel, questTopic) values (?,?,?,?,?)");


        if (text[i] == '#')
        {

            topic.clear();
            i++;
            while (text[i] != '#'){
                topic.push_back(text[i++]);
            }
        }
        if (text[i] == '$')
        {
             complexity.clear();

            i++;
            while (text[i] != '$')
                complexity.push_back(text[i++]);

        }
        if (text[i] == '@')
        {
            questNum++;
            i++;
            while (text[i] != '@')
                body.push_back(text[i++]);

            query.addBindValue(questNum);
            query.addBindValue(questListID);
            query.addBindValue(body);
            query.addBindValue(complexity);
            query.addBindValue(topic);
            query.exec();
            body.clear();
        }

        i++;
    }
    file.close();

    return 0;
}


int gentickets::generateTickets(QString ticketsListID)
{
    if (ticketsListID.length() == 0)
        return 1;                       // список билетов не выбран

    QSqlQuery helpQuery;
    helpQuery.prepare("select ticketsNum, questNumInTicket from TicketsList where ticketsListID = ?");
    helpQuery.addBindValue(ticketsListID);
    helpQuery.exec();
    helpQuery.first();

    QSqlQuery selectQuery; // тут получаем все данные для таблицы билеты (два последних поля)
    selectQuery.prepare("select questNumInTicket, questNumInList from Questions inner join QuestOfTickets on Questions.questListID = QuestOfTickets.questListID where QuestOfTickets.ticketsListID = ?");
    selectQuery.addBindValue(ticketsListID);
    selectQuery.exec();
    selectQuery.at();

    int numTickets = helpQuery.value(0).toInt();        // количество билетов
    int numQuestions = helpQuery.value(1).toInt();      // количество вопросов в билете

    QSqlQuery query_1;
    query_1.prepare("select count(*) from QuestOfTickets where ticketsListID = ?");
    query_1.addBindValue(ticketsListID);
    query_1.exec();
    query_1.first();
    int recNum = query_1.value(0).toInt();

    if (recNum != numQuestions)
        return 2;                     // количество определенных вопросов не равно количеству вопросов в билете

    QSqlQuery q3;
    q3.prepare("select questListID from QuestOfTickets where ticketsListID = ?");
    q3.addBindValue(ticketsListID);
    q3.exec();
    q3.at();

    while(q3.next()) {

        QSqlQuery query_1;
        query_1.prepare("select count(*) from Questions where questListID = ?");
        query_1.addBindValue(q3.value(0).toInt());
        query_1.exec();
        query_1.first();
        int questNum = query_1.value(0).toInt(); // число вопросов в списке
        if (numTickets != questNum)
            return 3;                     // если кол-во билетов и кол-во вопросов в каждом списке не совпадает
    }

    QSqlQuery insertQuery;
    int i = 1;  // i - ый билет

    QVariantList arg1;
    QVariantList arg2;
    QVariantList arg3;
    QVariantList arg4;
    while (selectQuery.next()){

        arg1.append(ticketsListID);
        arg2.append(i);
        arg3.append(selectQuery.value(0).toInt());
        arg4.append(selectQuery.value(1).toInt());
        i++;
        if (i > numTickets)
            i = 1;
    }
    insertQuery.prepare("insert into Tickets values (?,?,?,?)");
    insertQuery.addBindValue(arg1);
    insertQuery.addBindValue(arg2);
    insertQuery.addBindValue(arg3);
    insertQuery.addBindValue(arg4);
    insertQuery.execBatch();

    return 0;
}

QDomElement gentickets::makeElement(QDomDocument& domDoc, const QString& strName, const QString& strAttr, const QString& strText)
{
    QDomElement domElement = domDoc.createElement(strName);
    if (!strAttr.isEmpty()) {
        QDomAttr domAttr = domDoc.createAttribute("number");
        domAttr.setValue(strAttr);
        domElement.setAttributeNode(domAttr);
    }
    if (!strText.isEmpty()) {
        QDomText domText = domDoc.createTextNode(strText);
        domElement.appendChild(domText);
    }
    return domElement;
}

QVector<QDomElement> gentickets::tickets(QDomDocument& domDoc, QString ticketsIdForGenerating)
{
    QVector<QDomElement> ticketsList;

    QSqlQuery helpQuery;
    helpQuery.prepare("select ticketsNum, questNumInTicket from TicketsList where ticketsListID = ?");
    helpQuery.addBindValue(ticketsIdForGenerating);
    helpQuery.exec();
    helpQuery.first();

   // int numTickets = helpQuery.value(0).toInt();        // количество билетов
    int numQuestions = helpQuery.value(1).toInt();      // количество вопросов в билете

    QSqlQuery selectQuery;
    selectQuery.prepare("select ticketNum, questNumInTicket, questBody from Tickets natural join QuestOfTickets natural join QuestionList natural join Questions where Tickets.ticketsListID = ?");
    selectQuery.addBindValue(ticketsIdForGenerating/*переданный в аргументы*/);
    selectQuery.exec();
    selectQuery.at();

    int i = 0;
    int k = numQuestions; // количество вопросов в билете
    int j;

    QSqlQuery Query;
    Query.prepare("select discName, depName, zavDep from TicketsList natural join Dep natural join Disc where TicketsList.ticketsListID = ?");
    Query.addBindValue(ticketsIdForGenerating);
    Query.exec();
    Query.first();

    QDomElement domTicket;
    QDomElement domQuestions;
    QDomElement domQuestion;
    while (selectQuery.next()) {
        j = i % k;
        if (j == 0) {
            domTicket = makeElement(domDoc,"ticket",QString().setNum(selectQuery.value(0).toInt()/*номер билета*/)); // вставка тега билет и атрибута
            domTicket.appendChild(makeElement(domDoc, "disciplina", "", Query.value(0).toString()));
            domQuestions = makeElement(domDoc, "questions");
            domTicket.appendChild(domQuestions);
            domTicket.appendChild(makeElement(domDoc, "cafedra", "", Query.value(1).toString()));
            domTicket.appendChild(makeElement(domDoc, "zavcaf", "", Query.value(2).toString()));
        }
        domQuestion = makeElement(domDoc, "question", QString().setNum(selectQuery.value(1).toInt()/*номер вопроса в билете*/));
        domQuestion.appendChild(makeElement(domDoc, "questext", "", selectQuery.value(2).toString()));
        domQuestions.appendChild(domQuestion);
        ticketsList.push_back(domTicket);
        i++;
    }
    return ticketsList;
}



void gentickets::createOutputFile(QString ticketsListID, QString filename)
{

    QDomDocument doc;
    QDomElement  domElement = doc.createElement("tickets");
    QDomElement domMetaElement = doc.createElement("");
    doc.appendChild(domMetaElement);
    doc.appendChild(domElement);
    QVector<QDomElement> ticketssList = tickets(doc, ticketsListID);
    while (!ticketssList.isEmpty()){
       QDomElement el = ticketssList.first();
       domElement.appendChild(el);
       ticketssList.pop_front();
    }

    QFile file1("/home/user/output/xml/tickets.xml");
    if(file1.open(QIODevice::WriteOnly)) {
        QTextStream(&file1) << QString(QStringLiteral("<?xml version=\"1.0\" encoding=\"Utf-8\"?>\n")) + doc.toString();
        file1.close();
    }


   // QFile localoutfile("/home/user/output/outresult.odt");
    // QFile localoutfile(filename + ".odt");
     QFile localoutfile(filename);
    if (!localoutfile.open(QIODevice::ReadWrite | QIODevice::Text))
       qDebug() << "Файл для создания html не открыт";

    QXmlQuery xquery(QXmlQuery::XSLT20);
    xquery.setFocus(QUrl("/home/user/output/xml/tickets.xml"));
    xquery.setQuery(QUrl("/home/user/output/xml/tickets.xslt"));
    xquery.evaluateTo(&localoutfile);
    localoutfile.close();
}

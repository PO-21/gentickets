#ifndef QUESTIONSLISTFORM_H
#define QUESTIONSLISTFORM_H

#include <QWidget>
#include <abstractform.h>
#include "qcomboboxdelegate.h"
#include "qlineeditdelegate.h"
#include <QCloseEvent>

class mainForm;

namespace Ui {
class questionsListForm;
}

class questionsListDelegate : public QLineEditDelegate
{
public:
    questionsListDelegate() {}
    ~questionsListDelegate() {}
    virtual QWidget *createEditor(QWidget * parent,const QStyleOptionViewItem & option,
                              const QModelIndex & index) const;
private:


};

class questionsListForm : public QWidget, public AbstractForm
{
    Q_OBJECT

public:
    explicit                        questionsListForm(QWidget *parent = 0);
                                    ~questionsListForm();


    void                            setTableHeaders();
    void                            closeEvent(QCloseEvent *);


private slots:
    void                            insertButtonReact();
    void                            removeButtonReact();




private:
    Ui::questionsListForm *ui;
    QComboBoxDelegate* dep;
    QComboBoxDelegate* disc;
    QSqlRelationalDelegate* ds;


};

#endif // QUESTIONSLISTFORM_H

#include "mainform.h"
#include "ui_mainform.h"

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

mainForm::mainForm(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::mainForm)
{
    ui->setupUi(this);
    depF                = new depForm();
    discF               = new discForm();
    questionsListF      = new questionsListForm();
    ticketsListF        = new ticketsListForm();
    questionsLoadingF   = new questionsLoadingForm();
    questionsDefiningF  = new questionsDefiningForm();

    ui->tableView->hide();

//1 libre office writer должен быть закрыт
//2 написать коды ошибок и при каких случаях они вылетают

   // this->setGeometry(200, 150, 500, 520);
    depF->setGeometry(200, 200, 320, 400);
    discF->setGeometry(200, 200, 280, 380);
    questionsListF->setGeometry(100, 100, 680, 400);
    ticketsListF->setGeometry(100, 100, 960, 500);
    questionsLoadingF->setGeometry(100, 100, 600, 450);
    questionsDefiningF->setGeometry(100, 100, 400, 450);

    menu        = new QMenu("меню", this);
    tables      = new QMenu("таблицы", this);

    exit                = new QAction("выход", 0);
    dbOpenAct           = new QAction("открыть базу данных", 0);
    depAct              = new QAction("кафедра", 0);
    discAct             = new QAction("дисциплина", 0);
    questionsListAct    = new QAction("списки вопросов" ,0);
    ticketsListAct      = new QAction("добавить список билетов", 0);
    loadQuestionsToList = new QAction("загрузить вопросы в список", 0);
    defQuestionsList    = new QAction("определить списки вопросов", 0);

    menuBar = ui->menuBar;
    menuBar->addMenu(menu);
    menuBar->addMenu(tables);

    tables->addAction(depAct);
    tables->addAction(discAct);
    tables->addAction(questionsListAct);
    tables->addAction(ticketsListAct);
    menu->addAction(dbOpenAct);
    menu->addAction(loadQuestionsToList);
    menu->addAction(defQuestionsList);
    menu->addAction(exit);

    QObject::connect(dbOpenAct,             SIGNAL(triggered()), this, SLOT(connectToDatabase()));
    QObject::connect(exit,                  SIGNAL(triggered()), this, SLOT(close()));
    QObject::connect(depAct,                SIGNAL(triggered()), this, SLOT(openDepForm()));
    QObject::connect(questionsListAct,      SIGNAL(triggered()), this, SLOT(openQuestionsListForm()));
    QObject::connect(discAct,               SIGNAL(triggered()), this, SLOT(openDiscForm()));
    QObject::connect(ticketsListAct,        SIGNAL(triggered()), this, SLOT(openTicketsListForm()));
    QObject::connect(loadQuestionsToList,   SIGNAL(triggered()), this, SLOT(openQuestionsLoadingForm()));
    QObject::connect(defQuestionsList,      SIGNAL(triggered()), this, SLOT(openQuestionsDefiningFrom()));

    setAllWidgetsEnable(false);
}

mainForm::~mainForm()
{
    delete ui;
}

void mainForm::setTable()
{
    model_2 = new QSqlRelationalTableModel(0, db);
    model_2->setTable("Tickets");
    model_2->setEditStrategy(QSqlRelationalTableModel::OnFieldChange);
    model_2->select();
    ui->tableView->setModel(model_2);
    ui->tableView->hide();

    Tickets.setConnection(db);
}

void mainForm::fillTicketsGeneratingCmBox()
{
    ui->comboBox_3->clear();
    QSqlQuery query("select ticketsListName from TicketsList");
    QStringList s_list;
        while(query.next()) {
            s_list.append(query.value(0).toString());
        }
        ui->comboBox_3->addItems(s_list);
}

void mainForm::connectToDatabase()
{
    if (db.isOpen())
        return;
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("../gentickets.db");
    //db.setDatabaseName(QFileDialog::getOpenFileName(0, tr("Открыть файл"), QDir::currentPath()));
    db.open();

    if (!db.open()) {
        QMessageBox::warning(this, trUtf8("Ошибка!"), db.lastError().databaseText());

        return ;
    } else {
        qDebug() << "Successfully connected!";
        setAllWidgetsEnable(true);
    }
    QSqlQuery query(db);
    query.exec("pragma foreign_keys = 1;");

    setTable();
    fillTicketsGeneratingCmBox();
}



void mainForm::openDepForm()
{
    depF->setConnection(db);
    depF->setTable("Dep");
    depF->setMainForm(this);
    depF->setTableHeaders();
    this->setEnabled(false);
    depF->show();

}

void mainForm::openDiscForm()
{
    discF->setConnection(db);
    discF->setTable("Disc");
    discF->setMainForm(this);
    discF->setTableHeaders();
    this->setEnabled(false);
    discF->show();
}

void mainForm::openQuestionsListForm()
{
    questionsListF->setConnection(db);
    questionsListF->setTable("QuestionList");
    questionsListF->setMainForm(this);
    questionsListF->setTableHeaders();
    this->setEnabled(false);
    questionsListF->show();
}

void mainForm::openTicketsListForm()
{
    ticketsListF->setConnection(db);
    ticketsListF->setTable("TicketsList");
    ticketsListF->setMainForm(this);
    ticketsListF->setTableHeaders();
    this->setEnabled(false);
    ticketsListF->show();
}

void mainForm::openQuestionsLoadingForm()
{
    questionsLoadingF->setConnection(db);
    questionsLoadingF->setTable("Questions");
    questionsLoadingF->setMainForm(this);
    questionsLoadingF->setTableHeaders();
    questionsLoadingF->fillQuestListCmBox();
    this->setEnabled(false);
    questionsLoadingF->show();

}

void mainForm::openQuestionsDefiningFrom()
{
    questionsDefiningF->setConnection(db);
    questionsDefiningF->setTable("QuestOfTickets");
    questionsDefiningF->setMainForm(this);
    questionsDefiningF->setTableHeaders();
    questionsDefiningF->fillTicketsListCmBox();
    this->setEnabled(false);
    questionsDefiningF->show();

}


void mainForm::closeEvent(QCloseEvent *)
{
   delete depF;
   delete discF;
   delete questionsListF;
   delete ticketsListF;
   delete questionsLoadingF;
   delete questionsDefiningF;
}

void mainForm::on_comboBox_3_currentTextChanged(const QString &arg1)
{
    QSqlQuery query;
    query.prepare("select ticketsListID from TicketsList where ticketsListName = ?");
    query.addBindValue(arg1);
    query.exec();
    query.first();
    QString arg = query.value(0).toString();

    ticketsIdForGenerating = query.value(0).toString();
    qDebug() << ticketsIdForGenerating;
    model_2->setFilter("ticketsListID = '" + arg + "' order by questNumInList");
    model_2->select();
}

void mainForm::on_pushButton_2_clicked()
{


    QSqlQuery helpQuery;
    helpQuery.prepare("select count(*) from Tickets where ticketsListID = ?");
    helpQuery.addBindValue(ticketsIdForGenerating);
    helpQuery.exec();
    helpQuery.first();
    if (helpQuery.value(0).toInt() != 0) {
        QMessageBox::warning(this, "Ошибка", "Билеты для этого списка уже готовы!");
        return;
    }



   qDebug() << ticketsIdForGenerating;
   int result = Tickets.generateTickets(ticketsIdForGenerating);
   switch (result) {
   case 0:
       QMessageBox::information(this, "Сообщение", "Генерация прошла успешно!");
       break;
   case 1:
       QMessageBox::warning(this, "Ошибка", "Список билетов не выбран!");
       break;
   case 2:
       QMessageBox::warning(this, "Ошибка", "Число определенных вопросов не совпадает с числом вопросов в билете!");
       break;
   case 3:
       QMessageBox::warning(this, "Ошибка", "Количество вопросов в выбранных списках не совпадает с числом билетов!");
       break;
   default:
       break;
   }
   model_2->select();
}

void mainForm::setAllWidgetsEnable(bool flag)
{
    ui->pushButton->setEnabled(flag);
    ui->pushButton_2->setEnabled(flag);
    ui->pushButton_5->setEnabled(flag);
    tables->setEnabled(flag);
   // ui->tableView->setEnabled(flag);
    loadQuestionsToList->setEnabled(flag);
    defQuestionsList->setEnabled(flag);
}

void mainForm::on_pushButton_5_clicked()
{
    //QString filename = t.saveFile();
    //if (!filename.length())
     //   return;
    //
    //QDir dir;
    //dir.setPath(dir.homePath() + "/genticketsApp/outputFiles/");
    QString filename =  "data/outputFiles/output.doc";
    Tickets.createOutputFile(ticketsIdForGenerating, filename);

    QSqlQuery cpFilesQuery;
    cpFilesQuery.prepare("select objectsList from QuestionList where questListID in (select questListID from QuestOfTickets where ticketsListID = ?)");
    cpFilesQuery.addBindValue(ticketsIdForGenerating);
    cpFilesQuery.exec();
    cpFilesQuery.at();

    QString Objects("");
    while(cpFilesQuery.next()) {
        Objects.append(cpFilesQuery.value(0).toString() + " ");
    }

    Objects.remove(Objects.size() - 1, 1);

    QProcess  *proc = new QProcess(this);
    QString program = "sh";
    QStringList arguments;
    QString pathToScript("scripts/script.sh ");

    Objects.remove("Object");
    pathToScript.append(Objects);
    arguments << "-c" << pathToScript;
    proc->startDetached(program, arguments);

    QTest::qSleep(3000);


    QByteArray fileData;
    QFile file("data/outputFiles/output/content.xml");
    if(!file.open(QIODevice::ReadWrite))
        return;
    fileData = file.readAll();
    QString text(fileData);

    file.remove();
    text.replace(QString("&quot;"), QString("\"")); // replace text in string
    text.replace(QString("&lt;"), QString("<"));
    text.replace(QString("&gt;"), QString(">"));

    file.setFileName("data/outputFiles/output/content.xml");
    if(!file.open(QIODevice::ReadWrite))
        return;
    file.write(text.toUtf8());

    file.close();

    QTest::qSleep(1000);
    QProcess *proc2 = new QProcess(this);

    QString program2 = "sh";
    QStringList arguments2;
    arguments2 << "-c" << "scripts/script2.sh";
    proc2->startDetached(program2, arguments2);

}

void mainForm::on_pushButton_clicked()
{
    QSqlQuery helpQuery;
    helpQuery.prepare("select count(*) from Tickets where ticketsListID = ?");
    helpQuery.addBindValue(ticketsIdForGenerating);
    helpQuery.exec();
    helpQuery.first();
    if (helpQuery.value(0).toInt() == 0) {
        QMessageBox::warning(this, "Ошибка", "В списке нет билетов!");
        return;
    }

    QSqlQuery deleteQuery;
    deleteQuery.prepare("delete from Tickets where ticketsListID = ?");
    deleteQuery.addBindValue(ticketsIdForGenerating);
    deleteQuery.exec();

    model_2->select();
}



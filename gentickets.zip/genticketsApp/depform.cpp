#include "depform.h"
#include "ui_depform.h"
#include "mainform.h"
depForm::depForm(QWidget *parent) :
    QWidget(parent),
    AbstractForm(),
    ui(new Ui::depForm)
{
    ui->setupUi(this);
    table        = ui->tableView;
    insertButton = ui->pushButton;
    removeButton = ui->pushButton_2;
    ui->lineEdit->setVisible(false);
    QObject::connect(insertButton, SIGNAL(clicked()), this, SLOT(insertButtonReact()));
    QObject::connect(removeButton, SIGNAL(clicked()), this, SLOT(removeButtonReact()));
}

depForm::~depForm()
{
    delete ui;
}

void depForm::setTableHeaders()
{

     model->setHeaderData(1, Qt::Horizontal, "Название кафедры");
     model->setHeaderData(2, Qt::Horizontal, "Зав. Кафедрой");
     table->resizeColumnsToContents();
     table->hideColumn(0);
}

void depForm::closeEvent(QCloseEvent *ev)
{
    if (!mainF->isEnabled())
        mainF->setEnabled(true);
}


void depForm::insertButtonReact()
{
    QSqlRecord record;
    record = model->record();
    model->insertRecord(-1, record);
    model->select();
}

void depForm::removeButtonReact()
{
    if (!model->removeRow(table->currentIndex().row()))
        QMessageBox::warning(this, "Ошибка", model->lastError().databaseText());
    model->select();
}


#ifndef DEPFORM_H
#define DEPFORM_H

#include <QWidget>
#include <abstractform.h>
#include <QtSql>
#include <QCloseEvent>

class mainForm;
namespace Ui {
class depForm;
}

class depForm : public QWidget, public AbstractForm
{
    Q_OBJECT

public:
    explicit depForm(QWidget *parent = 0);
    ~depForm();
     void                                setTableHeaders();
     void                                closeEvent(QCloseEvent* ev);
private slots:
    void insertButtonReact();
    void removeButtonReact();



private:
    Ui::depForm *ui;
};

#endif // DEPFORM_H

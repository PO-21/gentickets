/********************************************************************************
** Form generated from reading UI file 'mainform.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINFORM_H
#define UI_MAINFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_mainForm
{
public:
    QAction *action;
    QAction *action_2;
    QAction *action_3;
    QAction *action_4;
    QAction *action_5;
    QAction *action_6;
    QWidget *centralWidget;
    QLabel *label_6;
    QComboBox *comboBox_3;
    QPushButton *pushButton_2;
    QTableView *tableView;
    QPushButton *pushButton_5;
    QPushButton *pushButton;
    QMenuBar *menuBar;

    void setupUi(QMainWindow *mainForm)
    {
        if (mainForm->objectName().isEmpty())
            mainForm->setObjectName(QStringLiteral("mainForm"));
        mainForm->resize(458, 187);
        action = new QAction(mainForm);
        action->setObjectName(QStringLiteral("action"));
        action_2 = new QAction(mainForm);
        action_2->setObjectName(QStringLiteral("action_2"));
        action_3 = new QAction(mainForm);
        action_3->setObjectName(QStringLiteral("action_3"));
        action_4 = new QAction(mainForm);
        action_4->setObjectName(QStringLiteral("action_4"));
        action_5 = new QAction(mainForm);
        action_5->setObjectName(QStringLiteral("action_5"));
        action_6 = new QAction(mainForm);
        action_6->setObjectName(QStringLiteral("action_6"));
        centralWidget = new QWidget(mainForm);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(30, 20, 201, 51));
        comboBox_3 = new QComboBox(centralWidget);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(30, 70, 181, 27));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(240, 70, 181, 27));
        tableView = new QTableView(centralWidget);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(20, 170, 451, 291));
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(30, 100, 181, 27));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(240, 100, 181, 27));
        mainForm->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(mainForm);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 458, 25));
        mainForm->setMenuBar(menuBar);

        retranslateUi(mainForm);

        QMetaObject::connectSlotsByName(mainForm);
    } // setupUi

    void retranslateUi(QMainWindow *mainForm)
    {
        mainForm->setWindowTitle(QApplication::translate("mainForm", "\320\223\320\265\320\275\320\265\321\200\320\260\321\206\320\270\321\217 \321\215\320\272\320\267\320\260\320\274\320\265\320\275\320\260\321\206\320\270\320\276\320\275\320\275\321\213\321\205 \320\261\320\270\320\273\320\265\321\202\320\276\320\262", 0));
        action->setText(QApplication::translate("mainForm", "\320\262\321\213\321\205\320\276\320\264", 0));
        action_2->setText(QApplication::translate("mainForm", "\320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\272\320\260\321\204\320\265\320\264\321\200\321\203", 0));
        action_3->setText(QApplication::translate("mainForm", "\320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \320\264\320\270\321\201\321\206\320\270\320\277\320\273\320\270\320\275\321\203", 0));
        action_4->setText(QApplication::translate("mainForm", "\320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\201\320\277\320\270\321\201\320\276\320\272 \320\262\320\276\320\277\321\200\320\276\321\201\320\276\320\262", 0));
        action_5->setText(QApplication::translate("mainForm", "\320\272\320\260\320\272\320\260", 0));
        action_6->setText(QApplication::translate("mainForm", "\321\204\320\260\321\213\320\262\320\260\321\204\321\213\320\262\320\260\321\204\321\213\320\262\320\260", 0));
        label_6->setText(QApplication::translate("mainForm", "\320\222\321\213\320\261\320\265\321\200\320\270\321\202\320\265 \321\201\320\277\320\270\321\201\320\276\320\272\n"
"\320\264\320\273\321\217 \320\263\320\265\320\275\320\265\321\200\320\260\321\206\320\270\320\270 \320\261\320\270\320\273\320\265\321\202\320\276\320\262", 0));
        pushButton_2->setText(QApplication::translate("mainForm", "\321\201\320\263\320\265\320\275\320\265\321\200\320\270\321\200\320\276\320\262\320\260\321\202\321\214 \320\261\320\270\320\273\320\265\321\202\321\213", 0));
        pushButton_5->setText(QApplication::translate("mainForm", "\321\201\320\276\321\205\321\200\320\260\320\275\320\270\321\202\321\214 \320\264\320\276\320\272\321\203\320\274\320\265\320\275\321\202", 0));
        pushButton->setText(QApplication::translate("mainForm", "\321\203\320\264\320\260\320\273\320\270\321\202\321\214 \320\261\320\270\320\273\320\265\321\202\321\213", 0));
    } // retranslateUi

};

namespace Ui {
    class mainForm: public Ui_mainForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINFORM_H

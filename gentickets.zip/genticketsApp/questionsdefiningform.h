#ifndef QUESTIONSDEFININGFORM_H
#define QUESTIONSDEFININGFORM_H

#include <QWidget>
#include <abstractform.h>
#include <qcomboboxdelegate.h>

class mainForm;

namespace Ui {
class questionsDefiningForm;
}

class questionsDefiningForm : public QWidget, public AbstractForm
{
    Q_OBJECT

public:
    explicit questionsDefiningForm(QWidget *parent = 0);
    ~questionsDefiningForm();
    void                                setTableHeaders();
    void                                closeEvent(QCloseEvent* ev);
    void                                fillTicketsListCmBox();

    QComboBox*                          ticketsListCmBox;
    int                                 ticketsListID;
private slots:
    void                                insertButtonReact();
    void                                removeButtonReact();

    void on_comboBox_currentTextChanged(const QString &arg1);

private:
    Ui::questionsDefiningForm *ui;
};

#endif // QUESTIONSDEFININGFORM_H

#ifndef MAINFORM_H
#define MAINFORM_H

#include <QMainWindow>
#include <gentickets_global.h>
#include <gentickets.h>
#include <QtSql>
#include <QMessageBox>
#include <QFileDialog>
#include <depform.h>
#include <discform.h>
#include <questionslistform.h>
#include <ticketslistform.h>
#include <questionsloadingform.h>
#include <questionsdefiningform.h>
#include "qcomboboxdelegate.h"
#include <QCloseEvent>
#include <QtXml>
#include <QTextDocument>
#include <QTextDocumentWriter>
#include <QTextEdit>
#include <QtXmlPatterns/QXmlQuery>
#include <QProcess>
#include <QDomDocument>
#include <QtTest/QTest>
#include <QDir>
#include <QDebug>


namespace Ui {
class mainForm;
}


class Tester : public QWidget
{
public:
    void openFile()
    {
        QFileDialog::getOpenFileName( this, tr("Open Document"), QDir::currentPath(), tr("Document files (*.doc *.rtf);;All files (*.*)"), 0, QFileDialog::DontUseNativeDialog );

        QString filename = QFileDialog::getOpenFileName(
                    this,
                    tr("Open Document"),
                    QDir::currentPath(),
                    tr("Document files (*.doc *.rtf);;All files (*.*)") );
        if( !filename.isNull() )
        {
            qDebug() << filename.toUtf8();
        }
    }

    void openFiles()
    {
        QStringList filenames = QFileDialog::getOpenFileNames(
                    this,
                    tr("Open Document"),
                    QDir::currentPath(),
                    tr("Documents (*.doc);;All files (*.*)") );
        if( !filenames.isEmpty() )
        {
            qDebug() << filenames.join(",").toUtf8();
        }
    }

    void openDir()
    {
        QString dirname = QFileDialog::getExistingDirectory(
                    this,
                    tr("Select a Directory"),
                    QDir::currentPath() );
        if( !dirname.isNull() )
        {
            qDebug() << dirname.toUtf8();
        }
    }

    QString saveFile()
    {
        QString filename = QFileDialog::getSaveFileName(
                    this,
                    tr("Сохранить"),
                    QDir::currentPath(),
                    tr("Documents (*.odt)") );
        if( !filename.isNull() )
        {
            qDebug() << filename.toUtf8();
            return filename;
        }
        return filename;
    }
};


class mainForm : public QMainWindow
{
    Q_OBJECT

    public:
        explicit mainForm(QWidget *parent = 0);
        ~mainForm();

        gentickets                              Tickets;
        Tester                                  t;
        QSqlDatabase                            db;
        QSqlRelationalTableModel*               model;
        QSqlRelationalTableModel*               model_2;
        QSqlRelationalTableModel*               model_3;
        QSqlRelationalTableModel*               model_4;
        QSqlRelationalTableModel*               model_5;


        depForm*                                depF;
        discForm*                               discF;
        questionsListForm*                      questionsListF;
        ticketsListForm*                        ticketsListF;
        questionsLoadingForm*                   questionsLoadingF;
        questionsDefiningForm*                  questionsDefiningF;

        QAction*                                exit;
        QAction*                                depAct;
        QAction*                                discAct;
        QAction*                                questionsListAct;
        QAction*                                ticketsListAct;
        QAction*                                dbOpenAct;
        QAction*                                loadQuestionsToList;
        QAction*                                defQuestionsList;


        QMenu*                                  menu;
        QMenu*                                  tables;
        QMenuBar*                               menuBar;

        void                                    setTable();
        int                                     questListID;
        int                                     ticketsListID;        
        void                                    fillTicketsGeneratingCmBox();
        void                                    closeEvent(QCloseEvent*);
        QString                                 ticketsIdForGenerating;


    private slots:

        void                                    connectToDatabase();
        void                                    openDepForm();
        void                                    openDiscForm();
        void                                    openQuestionsListForm();
        void                                    openTicketsListForm();
        void                                    openQuestionsLoadingForm();
        void                                    openQuestionsDefiningFrom();
        void                                    on_comboBox_3_currentTextChanged(const QString &arg1);
        void                                    on_pushButton_2_clicked();

        void                                    setAllWidgetsEnable(bool flag);

        void on_pushButton_5_clicked();
        void on_pushButton_clicked();

    private:
        Ui::mainForm*                           ui;
};



#endif // MAINFORM_H

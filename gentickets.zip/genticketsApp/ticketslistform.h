#ifndef TICKETSLISTFORM_H
#define TICKETSLISTFORM_H

#include <QWidget>
#include <abstractform.h>
#include "qlineeditdelegate.h"
class mainForm;

namespace Ui {
class ticketsListForm;
}


class ticketsListDelegate : public QLineEditDelegate
{
public:
    ticketsListDelegate() {}
    ~ticketsListDelegate() {}
    virtual QWidget *createEditor(QWidget * parent,const QStyleOptionViewItem & option,
                              const QModelIndex & index) const;
private:


};

class ticketsListForm : public QWidget, public AbstractForm
{
    Q_OBJECT

public:
    explicit ticketsListForm(QWidget *parent = 0);
    ~ticketsListForm();
    void                                setTableHeaders();
    void                                closeEvent(QCloseEvent*ev);
private slots:
   void insertButtonReact();
   void removeButtonReact();



private:
    Ui::ticketsListForm *ui;

};

#endif // TICKETSLISTFORM_H
